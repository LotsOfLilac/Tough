module.exports = {
  autoUpdate: true,
  isSteam: false,
};
