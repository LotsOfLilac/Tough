// default values for release.yml
module.exports = {
  autoUpdate: true,
  isSteam: false,
};
