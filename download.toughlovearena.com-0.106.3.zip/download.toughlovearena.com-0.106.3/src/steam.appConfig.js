module.exports = {
  autoUpdate: false,
  isSteam: true,
};
